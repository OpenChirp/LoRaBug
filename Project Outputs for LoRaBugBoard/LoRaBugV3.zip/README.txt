Standard FR4 laminate
Thickness 0.062"
Drill sizes are actual tool sizes
Drill Tolerance +/- 0.008"
Adjust tools to free sizes where possible